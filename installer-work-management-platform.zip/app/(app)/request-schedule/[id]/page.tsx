'use client';

import { useCallback, useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Pencil, Calendar, MapPin, Ban, ClipboardCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/providers';
import type { Activity, ActivityPersonnel, ActivityEvidence, ActivityCategory, FormReview } from '@/lib/types';
import { formatDate, formatDateTime } from '@/lib/utils';
import { StatusBadge } from '@/components/shared/StatusBadge';
import { LoadingState, ErrorState } from '@/components/shared/States';
import { ActivityFormModal } from '../_components/ActivityFormModal';
import { PersonnelPanel } from './_components/PersonnelPanel';
import { EvidencePanel } from './_components/EvidencePanel';
import { ExecutionPanel } from './_components/ExecutionPanel';

export default function ActivityDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();
  const [activity, setActivity] = useState<Activity | null>(null);
  const [projectLatLng, setProjectLatLng] = useState<{ lat: number | null; lng: number | null }>({ lat: null, lng: null });
  const [personnel, setPersonnel] = useState<ActivityPersonnel[]>([]);
  const [evidence, setEvidence] = useState<ActivityEvidence[]>([]);
  const [review, setReview] = useState<FormReview | null>(null);
  const [categories, setCategories] = useState<ActivityCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editOpen, setEditOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: act, error: actErr } = await supabase
        .from('activities')
        .select('*, activity_categories(id, name, code, requires_gps, requires_evidence, requires_personnel, evidence_min_count, gps_radius_m), projects(id, name, code, latitude, longitude)')
        .eq('id', id)
        .single();
      if (actErr) throw actErr;
      setActivity(act as Activity);
      const proj = (act as unknown as { projects: { latitude: number | null; longitude: number | null } }).projects;
      setProjectLatLng({ lat: proj?.latitude ?? null, lng: proj?.longitude ?? null });

      const [{ data: pers }, { data: evid }, { data: rev }, { data: cats }] = await Promise.all([
        supabase.from('activity_personnel').select('*').eq('activity_id', id).order('created_at'),
        supabase.from('activity_evidence').select('*').eq('activity_id', id).order('uploaded_at', { ascending: false }),
        supabase.from('form_reviews').select('*').eq('activity_id', id).order('created_at', { ascending: false }).limit(1).maybeSingle(),
        supabase.from('activity_categories').select('*').order('sort_order'),
      ]);
      setPersonnel((pers as ActivityPersonnel[]) ?? []);
      setEvidence((evid as ActivityEvidence[]) ?? []);
      setReview((rev as FormReview) ?? null);
      setCategories((cats as ActivityCategory[]) ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load activity.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { load(); }, [load]);

  async function handleCancel() {
    if (!confirm('Cancel this activity? This cannot be undone from the UI.')) return;
    const { error: err } = await supabase.rpc('iwm_set_activity_status', { p_activity_id: id, p_status: 'cancelled' });
    if (!err) load();
  }

  if (loading) return <LoadingState />;
  if (error || !activity) return <ErrorState message={error ?? 'Activity not found.'} onRetry={load} />;

  const canEditSchedule = user && ['admin', 'supervisor'].includes(user.role);
  const targetLat = activity.target_latitude ?? projectLatLng.lat;
  const targetLng = activity.target_longitude ?? projectLatLng.lng;
  const locked = activity.status === 'completed' || activity.status === 'cancelled';

  return (
    <div className="max-w-3xl mx-auto">
      <button onClick={() => router.push('/request-schedule')} className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to Request Schedule
      </button>

      <div className="bg-white rounded-card border border-slate-200 shadow-card p-5 mb-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <span className="text-xs font-semibold text-brand-700 uppercase tracking-wide">{activity.activity_categories?.name}</span>
            <h1 className="text-lg font-semibold text-slate-900">{activity.title}</h1>
            <p className="text-xs text-slate-400 font-mono mt-0.5">{activity.request_number}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <StatusBadge status={activity.status} />
            {canEditSchedule && !locked && (
              <button onClick={() => setEditOpen(true)} className="text-slate-400 hover:text-slate-600"><Pencil className="h-4 w-4" /></button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 text-sm">
          <InfoRow label="Project">
            <Link href={`/projects/${activity.project_id}`} className="text-brand-600 hover:underline">{activity.projects?.name}</Link>
          </InfoRow>
          <InfoRow label="Customer">{activity.customer_name || '—'}</InfoRow>
          <InfoRow label="Scheduled"><span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{formatDate(activity.scheduled_date)}{activity.start_time ? ` · ${activity.start_time.slice(0, 5)}` : ''}</span></InfoRow>
          <InfoRow label="Location"><span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{activity.location_address || '—'}</span></InfoRow>
          <InfoRow label="Priority"><span className="capitalize">{activity.priority}</span></InfoRow>
          <InfoRow label="Completed">{formatDateTime(activity.completed_at)}</InfoRow>
        </div>

        {activity.notes && <p className="text-sm text-slate-600 mt-3 bg-slate-50 rounded-control p-3">{activity.notes}</p>}

        {review && (
          <div className="mt-3 flex items-center gap-2 text-sm">
            <ClipboardCheck className="h-4 w-4 text-slate-400" />
            <span className="text-slate-500">Form Review:</span>
            <StatusBadge status={review.status} />
          </div>
        )}

        {canEditSchedule && !locked && (
          <button onClick={handleCancel} className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-red-500 hover:text-red-700">
            <Ban className="h-3.5 w-3.5" /> Cancel Activity
          </button>
        )}
      </div>

      <div className="space-y-4">
        <ExecutionPanel activity={activity} targetLat={targetLat} targetLng={targetLng} canAct={!!user} onChanged={load} />
        <PersonnelPanel activityId={activity.id} personnel={personnel} locked={locked} canEdit={!!user} isStaff={!!canEditSchedule} onChanged={load} />
        <EvidencePanel
          activityId={activity.id}
          projectId={activity.project_id}
          evidence={evidence}
          locked={locked}
          minRequired={activity.activity_categories?.requires_evidence ? (activity.activity_categories?.evidence_min_count ?? 1) : 0}
          onChanged={load}
        />
      </div>

      <ActivityFormModal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        onSaved={() => { setEditOpen(false); load(); }}
        categories={categories}
        activity={activity}
      />
    </div>
  );
}

function InfoRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs text-slate-400">{label}</p>
      <p className="text-slate-700 mt-0.5">{children}</p>
    </div>
  );
}

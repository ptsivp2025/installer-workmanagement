'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import {
  LayoutDashboard, CalendarClock, ClipboardCheck, FolderKanban, Settings, LogOut, Menu, X,
} from 'lucide-react';
import { useAuth } from '@/app/providers';
import { clearSession } from '@/lib/auth';
import { roleLabel } from '@/lib/constants';

const NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/projects', label: 'Projects', icon: FolderKanban },
  { href: '/request-schedule', label: 'Request Schedule', icon: CalendarClock },
  { href: '/form-review', label: 'Form Review', icon: ClipboardCheck },
  { href: '/project-progress', label: 'Project Progress', icon: FolderKanban },
];

const ADMIN_NAV = { href: '/admin/categories', label: 'Admin Panel', icon: Settings };

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, loading, setUserProfile } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  async function handleLogout() {
    clearSession();
    setUserProfile(null);
    router.replace('/login');
  }

  const items = user?.role === 'admin' ? [...NAV, ADMIN_NAV] : NAV;

  return (
    <div className="min-h-screen flex">
      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 inset-x-0 h-14 bg-white border-b border-slate-200 z-40 flex items-center justify-between px-4">
        <button onClick={() => setMobileOpen(true)} className="text-slate-600"><Menu className="h-5 w-5" /></button>
        <span className="font-semibold text-slate-900 text-sm">Installer Work Management</span>
        <div className="w-5" />
      </div>

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="h-14 flex items-center justify-between px-5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-brand-600 text-white flex items-center justify-center text-sm font-bold">IW</div>
            <span className="font-semibold text-slate-900 text-sm">Work Management</span>
          </div>
          <button onClick={() => setMobileOpen(false)} className="lg:hidden text-slate-400"><X className="h-5 w-5" /></button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
          {items.map(item => {
            const Icon = item.icon;
            const active = pathname === item.href || pathname.startsWith(item.href + '/');
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 rounded-control px-3 py-2 text-sm font-medium transition ${
                  active ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-slate-100 p-3">
          {!loading && user && (
            <div className="flex items-center gap-2 px-2 py-2">
              <div className="h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-semibold text-slate-600">
                {user.full_name?.charAt(0) ?? user.username.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-slate-800 truncate">{user.full_name || user.username}</p>
                <p className="text-xs text-slate-400">{roleLabel(user.role)}</p>
              </div>
              <button onClick={handleLogout} title="Sign out" className="text-slate-400 hover:text-red-500">
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </aside>

      {mobileOpen && <div className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />}

      <main className="flex-1 min-w-0 pt-14 lg:pt-0">
        <div className="max-w-7xl mx-auto p-4 sm:p-6">{children}</div>
      </main>
    </div>
  );
}
